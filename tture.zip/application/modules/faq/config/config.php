<?php
define('TBL_FAQ', 'faq');
?>