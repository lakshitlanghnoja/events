<table cellspacing="2" cellpadding="2" border="0">
    <tr>
        <td><?php echo lang('activation_link_message'); ?></td>
        <td><?php echo anchor('users/activation/'.$activation_code, lang('click-here'), 'title="'.lang('click-here').'" '); ?></td>
    </tr>
  
</table>