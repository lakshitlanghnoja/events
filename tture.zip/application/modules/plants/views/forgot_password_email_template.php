<table cellspacing="2" cellpadding="2" border="0">
    <tr>
        <td><?php echo lang('forgot-password-template-msg')?></td>
        
    </tr>
    <tr>
        <td><?php echo lang('email'); ?> :- <?php echo $email;?></td>        
    </tr>
    <tr>
        <td><?php echo lang('password'); ?> :- <?php echo $password;?></td>        
    </tr>
  
</table>