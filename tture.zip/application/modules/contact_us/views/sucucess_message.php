<tr>
    <td>
        <h1>Contact Us</h1>
    </td>
</tr>
<tr class="content">
    <td style="background-color: #75C386; color: #FFFFFF; font-weight: bold; padding: 8px 0px 8px 15px">
        Your contact details sent successfully
    </td>
</tr>

