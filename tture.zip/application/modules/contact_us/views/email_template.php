<table cellspacing="2" cellpadding="2" border="0">
    <tr>
        <td>Name :</td>
        <td><?php echo $name; ?></td>
    </tr>
    <tr>
        <td>Email :</td>
        <td><?php echo $email; ?></td>
    </tr>
    <tr>
        <td>Subject :</td>
        <td><?php echo $subject; ?></td>
    </tr>
    <tr>
        <td>Message :</td>
        <td><?php echo $message; ?></td>
    </tr>
</table>