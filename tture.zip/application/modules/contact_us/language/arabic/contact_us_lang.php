<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['sample_label'] = 'Sample site';
?>
