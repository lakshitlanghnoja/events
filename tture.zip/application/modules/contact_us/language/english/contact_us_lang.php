<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['sample_label'] = 'Sample site';
$lang['detail_sent'] = 'Your contact details sent successfully';
?>
