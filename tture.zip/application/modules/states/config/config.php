<?php
define('TBL_STATES', 'states');
?>