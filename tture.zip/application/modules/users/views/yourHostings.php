
<h4 class="text-center">Your Hostings</h4>

<ul class="trip-list">
    <?php
    if (is_array($trip_created_by_you) && !empty($trip_created_by_you)) {
        foreach ($trip_created_by_you as $trip) {
            ?>
            <li class="clearfix">
                <div class="row">
                    <div class="col-md-3 col-sm-4">            
                        <?php
                        if (isset($trip['e']['display_image']) && !empty($trip['e']['display_image'])) {
                            ?>
                            <span class="thumb">
                                <?php
                                $baseGalleryImageURL = $ci->config->item('eventGalleryImageURL');
                                $imgSRC = $baseGalleryImageURL . $trip['e']['display_image'];
                                ?>
                                <img src="<?php echo $imgSRC; ?>">  
                            </span>
                            <?php
                        }
                        ?>                                                                          
                    </div>
                    <div class="col-md-6 col-sm-4">
                        <div class="clearfix">
                            <h4 class="pull-left"><a href="<?php echo base_url('event/index/' . $trip['e']['slug']); ?>"><?php echo $trip['e']['title']; ?></a></h4>   
                            
                        </div>
                        <ul class="service-details">
                            
                            <li class="eventDetail">
                                <?php
                                $totalStar = 0;
                                if (isset($trip['custom']['event_rating']) && !empty($trip['custom']['event_rating']) && is_numeric($trip['custom']['event_rating'])) {
                                    $totalStar = ceil($trip['custom']['event_rating']);
                                }
                                for ($i = 0; $i < $totalStar; $i++) {
                                    ?>
                                    <i class="fa fa-star"></i>
                                    <?php
                                }
                                for ($i = 0; $i < (5 - $totalStar); $i++) {
                                    ?>
                                    <i class="fa fa-star-o"></i>
                                    <?php
                                }
                                ?>
                            </li>
                            <li class="eventDetail">
                                <label>PrimaeventDetailry location:</label>
                                <?php echo $trip['e']['source_city'] . ', ' . $trip['e']['source_state'] ?>
                            </li>
                            <li class="eventDetail">
                                <label>Duration:</label>
                                <?php echo $trip['e']['duration']; ?> hours
                            </li>                            
                            <li class="eventDetail">
                                <label>Total Sheets Booked:</label>
                                <?php echo $trip['custom']['userJoined']; ?>
                            </li>                            
                            <li class="eventDetail">
                                <label>Transportation:</label>
                                <?php echo $trip['e']['transportation']; ?>
                            </li>
                        </ul>                                    
                    </div>
                    <div class="col-md-3 col-sm-4 completeEventSection">
                        <?php
                        if ($trip['ej']['completed'] == "0") {
                            ?>
                            <div class="right-column">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <a href="#" title="Redeem Payment" class="btn-secondary btn-small">Redeem Payment</a>
                                    </div>
                                </div>
                                
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </li>
            <?php
        }
    } else {
        ?>
        <li class="clearfix">
            You have not created any event till now.
        </li>
        <?php
    }
    ?>

</ul>