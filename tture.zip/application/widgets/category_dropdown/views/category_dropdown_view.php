<?php
echo form_dropdown($name, $category_list, $value, 'id="'.$id.'"');
?>