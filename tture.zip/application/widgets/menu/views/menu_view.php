<?php 

// echo add_js('sample', 'menu', 'widgets');
// echo add_css(array('sample'), 'menu', 'widgets');
 //pr($parentId);
 //pre($menu);
 
 echo buildMenu($parentId, $menu);
?>