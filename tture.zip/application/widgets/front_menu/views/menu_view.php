<?php 

 //echo add_js('sample', 'menu', 'widgets');
 //echo add_css(array('sample'), 'menu', 'widgets');
 
 echo buildMenu($parentId, $menu);
?>