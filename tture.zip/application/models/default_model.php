<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Default_model extends Base_Model {

	public function default_test()
    {    	
    	return "Defalt return val";
    }		
}
